Họ và tên: Lưu Đức Vũ
MSSV: 19120433

Các chức năng đã làm được:
- Vẽ được các điểm, đoạn thẳng, hình e-líp và hình chữ nhật
(click vào 1 trong 4 icon ở cuối để vẽ - mặc định là điểm)
- Thay đổi được toàn bộ màu của các hình
(Choose -> Color)
- Lưu các hình vào file (click icon save) và có thể đọc lại file
(click icon open) để khôi phục các hình
- Có nút blank khi click vào thì sẽ xóa trắng màn hình (vẫn còn lỗi
là hình cuối cùng khi vẽ vần còn nằm lại, chỉ được xóa khi vẽ một
hình bất kì khác)
- Các icon copy, paste, cut và delete chỉ làm cảnh
-Chạy ở chế độ debug, x86 - Crtl F5 (ý em là cái solution 
configurations)

Link video demo: https://youtu.be/GE-0dkeF8xk