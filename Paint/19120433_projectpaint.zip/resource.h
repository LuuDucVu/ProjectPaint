//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Paint.rc
//
#define IDC_MYICON                      2
#define IDD_PAINT_DIALOG                102
#define IDS_APP_TITLE                   103
#define IDD_ABOUTBOX                    103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDI_PAINT                       107
#define IDI_SMALL                       108
#define IDC_PAINT                       109
#define ID_TOOLBAR                      110
#define ID_FILE_NEW                     111
#define ID_FILE_OPEN                    112
#define ID_FILE_SAVE                    113
#define ID_EDIT_CUT                     114
#define ID_EDIT_COPY                    115
#define ID_EDIT_PASTE                   116
#define ID_EDIT_DELETE                  117
#define ID_DRAW_LINE                    118
#define ID_DRAW_ELLIPSE                 119
#define ID_DRAW_RECTANGLE               120
#define ID_DRAW_POINT                   121
#define IDR_MAINFRAME                   128
#define IDB_BITMAP2                     130
#define IDB_BITMAP3                     134
#define IDB_BITMAP1                     135
#define IDB_BITMAP4                     136
#define IDB_BITMAP5                     137
#define ID_CHOOSE_FONT                  32771
#define ID_CHOOSE_COLOR                 32772
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        138
#define _APS_NEXT_COMMAND_VALUE         32773
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           123
#endif
#endif
